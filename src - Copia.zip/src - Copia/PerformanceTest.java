import java.util.Arrays;

public class PerformanceTest {
    public static long measureExecutionTime(Runnable sortingAlgorithm) {
        long startTime = System.nanoTime();
        sortingAlgorithm.run();
        return System.nanoTime() - startTime;
    }

    public static void main(String[] args) {
        int[] sizes = {128, 256, 512, 1024, 2048, 4096, 65536};
        int numExecutions = 10;
        for (int size : sizes) {
            int[] ascendingArray = TestScenarios.generateAscendingArray(size);
            int[] descendingArray = TestScenarios.generateDescendingArray(size);
            int[] randomArrayNoDuplicates = TestScenarios.generateRandomArray(size, false);
            int[] randomArrayWithDuplicates = TestScenarios.generateRandomArray(size, true);

            long[] bubbleSortTimes = new long[numExecutions];
            long[] insertionSortTimes = new long[numExecutions];
            long[] selectionSortTimes = new long[numExecutions];
            long[] heapSortTimes = new long[numExecutions];
            long[] shellSortTimes = new long[numExecutions];
            long[] mergeSortTimes = new long[numExecutions];
            long[] quickSortTimes = new long[numExecutions];

            for (int i = 0; i < numExecutions; i++) {
                final int[] arrayCopy1 = Arrays.copyOf(ascendingArray, size);
                bubbleSortTimes[i] = measureExecutionTime(() -> SortingAlgorithms.bubbleSort(arrayCopy1));
                
                final int[] arrayCopy2 = Arrays.copyOf(ascendingArray, size);
                insertionSortTimes[i] = measureExecutionTime(() -> SortingAlgorithms.insertionSort(arrayCopy2));
                
                final int[] arrayCopy3 = Arrays.copyOf(ascendingArray, size);
                selectionSortTimes[i] = measureExecutionTime(() -> SortingAlgorithms.selectionSort(arrayCopy3));
                
                final int[] arrayCopy4 = Arrays.copyOf(ascendingArray, size);
                heapSortTimes[i] = measureExecutionTime(() -> SortingAlgorithms.heapSort(arrayCopy4));
                
                final int[] arrayCopy5 = Arrays.copyOf(ascendingArray, size);
                shellSortTimes[i] = measureExecutionTime(() -> SortingAlgorithms.shellSort(arrayCopy5));
                
                final int[] arrayCopy6 = Arrays.copyOf(ascendingArray, size);
                mergeSortTimes[i] = measureExecutionTime(() -> SortingAlgorithms.mergeSort(arrayCopy6));
                
                final int[] arrayCopy7 = Arrays.copyOf(ascendingArray, size);
                quickSortTimes[i] = measureExecutionTime(() -> SortingAlgorithms.quickSort(arrayCopy7, 0, size - 1));
            }

            System.out.println("Array Size: " + size);
            System.out.println("Bubble Sort Avg Time: " + Arrays.stream(bubbleSortTimes).average().orElse(0));
            System.out.println("Insertion Sort Avg Time: " + Arrays.stream(insertionSortTimes).average().orElse(0));
            System.out.println("Selection Sort Avg Time: " + Arrays.stream(selectionSortTimes).average().orElse(0));
            System.out.println("Heap Sort Avg Time: " + Arrays.stream(heapSortTimes).average().orElse(0));
            System.out.println("Shell Sort Avg Time: " + Arrays.stream(shellSortTimes).average().orElse(0));
            System.out.println("Merge Sort Avg Time: " + Arrays.stream(mergeSortTimes).average().orElse(0));
            System.out.println("Quick Sort Avg Time: " + Arrays.stream(quickSortTimes).average().orElse(0));
        }
    }
}
